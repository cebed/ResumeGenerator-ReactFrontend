import React, {Component} from 'react';

class Footer extends Component {

    render() {
        return (

            <footer>

                <ul>
                    <li className="logo">20<span>19</span></li>
                </ul>

            </footer>

        );
    }
}

export default Footer;
